#ifndef __LCD_HW_H
#define __LCD_HW_H

#ifdef PB1
#define LCD_RST PD7
#define SPI_CS  PB1
#define SPI_MOSI PB3
#define SPI_SCK PB5
#define SPI_SS  PB2
#define LCD_RS  PB0
#define LCD_BL  PD6
#else 
#define LCD_RST PORTD7
#define SPI_CS  PORTB1
#define SPI_SS PORTB2
#define SPI_MOSI PORTB3
#define SPI_SCK PORTB5
#define LCD_RS  PORTB0
#define LCD_BL  PORTD6
#endif

#define LCD_CS_L()  	PORTB &= ~(1<<SPI_CS);
#define LCD_CS_H()	PORTB |= (1<<SPI_CS);

#define RS_L()	PORTB &= ~(1<<LCD_RS);
#define RS_H()	PORTB |= (1<<LCD_RS);

#define SD_CS_DDR		DDRD
#define SD_CS_PORT	PORTD
#define SD_CS_PIN		5


//PORT deifinition for Touchpanel
//SPI configuration (Platform dependent)
#define SPI_DDR		DDRB
#define SPI_PORT 	PORTB
#define DD_MOSI		3
#define DD_MISO		4
#define DD_SCK		5



#endif

