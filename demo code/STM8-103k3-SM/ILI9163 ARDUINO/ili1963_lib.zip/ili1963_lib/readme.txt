The folder ILI9163 contains Arduino library and example sketch for 1.77" TFT sheild.
Place this folder in the Arduino IDE libraries folder

The bitmap, tiger_s.bmp, is a bitmap file that can be used with the ILI9163_menu
example.  Place this file in the root directory of the SD card.