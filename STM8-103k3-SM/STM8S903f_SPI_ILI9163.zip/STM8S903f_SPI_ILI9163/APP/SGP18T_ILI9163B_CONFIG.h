#ifndef __SGP18T_ILI9163B_CONFIG_H__
#define __SGP18T_ILI9163B_CONFIG_H__



#include "ILI9163.h"



#define PRINTCHAR16		1  	
#define	PRINTCHAR6		1
#define PRINTCHAR8		1


#endif //SGP18T_ILI9163B_config.h