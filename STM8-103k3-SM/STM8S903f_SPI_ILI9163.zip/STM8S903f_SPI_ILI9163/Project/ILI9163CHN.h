#ifndef __ILI9163CHN_H__
#define __ILI9163CHN_H__
void LCD_PutString(unsigned short x, unsigned short y, unsigned char *s, unsigned int fColor, unsigned int bColor);
#endif